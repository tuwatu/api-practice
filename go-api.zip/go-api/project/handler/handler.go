package handler

import (
	"net/http"
)

// 大文字 → 外部パッケージから呼べる
// リクエスト振り分け関数
func RequestClassification(r *http.Request) http.ResponseWriter {
	// 適したサービス層を呼び出して結果を返す
	if(p )
	return w
}

func  CreateResponseWriter() http.ResponseWriter{
	return w
}
